package com.example.zymik.zeyuma_rakhimonalisa_assignment04;

public class tblOrders {
    //private fields
    private int orderId, itemId, customerId;
    private String amount, deliveryDate, status;

    //no argument constructor
    public tblOrders() {
    }


    public tblOrders(int orderId, int itemId, int customerId, String amount, String deliveryDate, String status) {
        this.orderId = orderId;
        this.itemId = itemId;
        this.customerId = customerId;
        this.amount = amount;
        this.deliveryDate = deliveryDate;
        this.status = status;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getDeliveryDate() {
        return deliveryDate;
    }

    public void setDeliveryDate(String deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}