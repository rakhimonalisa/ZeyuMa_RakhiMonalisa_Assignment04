package com.example.zymik.zeyuma_rakhimonalisa_assignment04;

import android.content.ContentValues;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ItemList extends AppCompatActivity {

    private tblmgrItems itemsManager;
    private final static String TABLE_NAME = "Item";
    //sql string to create the table
    private static final String tableCreatorString =
            "CREATE TABLE " + TABLE_NAME + " (itemId integer primary key, itemName text, price text, category text);";
    private EditText txtItemIdRep, txtItemNameRep, txtPriceRep, txtCategoryRep;
    private Button btnAddItem, btnShowItem, btnEditItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_list);

        txtItemIdRep = (EditText) findViewById(R.id.txtItemIdRep);
        txtItemNameRep = (EditText) findViewById(R.id.txtItemNameRep);
        txtPriceRep = (EditText) findViewById(R.id.txtPriceRep);
        txtCategoryRep = (EditText) findViewById(R.id.txtCategoryRep);

        btnAddItem = (Button) findViewById(R.id.btnAddItem);
        btnEditItem = (Button) findViewById(R.id.btnEditItem);
        btnShowItem = (Button) findViewById(R.id.btnShowItem);

        // instantiate the StudentManager
        // initialize the tables
        try {
            itemsManager = new tblmgrItems(this);
            //create the table
            itemsManager.dbInitialize(TABLE_NAME, tableCreatorString);
        } catch (Exception exception) {
            Toast.makeText(ItemList.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
            Log.i("Error: ", exception.getMessage());
        }
    }// end of onCreate

    //Event handling
    public void addItem(View view) {
        //read values for text fields
        int itemId = Integer.parseInt(txtItemIdRep.getText().toString());
        String itemName = txtItemNameRep.getText().toString();
        String itemPrice = txtPriceRep.getText().toString();
        String itemCategory = txtCategoryRep.getText().toString();
        //initialize ContentValues object with the new customer
        ContentValues itemContentValues = new ContentValues();
        itemContentValues.put("itemId", itemId);
        itemContentValues.put("itemName", itemName);
        itemContentValues.put("price", itemPrice);
        itemContentValues.put("category", itemCategory);
        //
        try {
            itemsManager.addRow(itemContentValues);
        } catch (Exception exception) {
            //
            Toast.makeText(ItemList.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
            Log.i("Error: ", exception.getMessage());
        }
    }

    //
    public void showItem(View view) {
        try {
            tblItems item = itemsManager.getItemById(txtItemIdRep.getText().toString(), "itemId");
            txtItemNameRep.setText(item.getItemName());
            txtPriceRep.setText(item.getPrice());
            txtCategoryRep.setText(item.getCategory());
        } catch (Exception exception) {
            Toast.makeText(ItemList.this,
                    exception.getMessage(), Toast.LENGTH_SHORT).show();
            Log.i("Error: ", exception.getMessage());
        }
    }

    public void editItem(View view) {
        int itemId = Integer.parseInt(txtItemIdRep.getText().toString());

        String itemName = txtItemNameRep.getText().toString();
        String itemPrice = txtPriceRep.getText().toString();
        String itemCategory = txtCategoryRep.getText().toString();

        try {
            ContentValues itemContentValues = new ContentValues();
            itemContentValues.put("itemId", itemId);
            itemContentValues.put("itemName", itemName);
            itemContentValues.put("price", itemPrice);
            itemContentValues.put("category", itemCategory);
            //edit the row
            boolean b = itemsManager.editRow(itemId, "itemId", itemContentValues);
        } catch (Exception exception) {
            Toast.makeText(ItemList.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
            Log.i("Error: ", exception.getMessage());
        }
    }
}
