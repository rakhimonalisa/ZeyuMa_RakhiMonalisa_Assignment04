package com.example.zymik.zeyuma_rakhimonalisa_assignment04;

import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class PlaceOrder extends AppCompatActivity {

    private tblmgrCustomer customerManager;
    private final static String TABLE_NAME = "Customer";
    //sql string to create the table
    private static final String tableCreatorString =
            "CREATE TABLE " + TABLE_NAME + " (customerId integer primary key, username text, password text, firstName text, lastName text, address text, postalCode text);";

    private tblmgrOrders ordersManager;
    private final static String TABLE_NAME_ORDER = "Orders";
    //sql string to create the table
    private static final String tableCreatorStringOrder =
            "CREATE TABLE " + TABLE_NAME_ORDER + " (orderId integer primary key, itemId integer, customerId integer, amount text, deliveryDate text, status text);";

    private tblmgrItems itemManager;
    private final static String TABLE_NAME_ITEM = "Item";
    //sql string to create the table
    private static final String tableCreatorStringItem =
            "CREATE TABLE " + TABLE_NAME_ITEM + " (itemId integer primary key, itemName text, price text, category text);";

    //EditText for Customer
    private EditText txtUsername, txtFirstName, txtLastName, txtAddress, txtPostalCode;
    //EditText for Order
    private EditText txtOrderId, txtOItemId, txtOAmount, txtODeliveryDate, txtOStatus;
    //Button for Customer
    private Button btnAddCustomer, btnShowCustomer, btnEditCustomer;
    //Button for Order
    private Button btnAddOrder, btnShowOrder, btnEditOrder, btnViewItemCus;
    private String idCus, usernameCus, passwordCus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place_order);
        SharedPreferences customerPreference = getSharedPreferences("CustomerInfo", MODE_PRIVATE);
        idCus = customerPreference.getString("CustomerId", "");
        usernameCus = customerPreference.getString("CustomerUsername", "");
        passwordCus = customerPreference.getString("CustomerPassword", "");

        //Customer Table
        txtUsername = (EditText) findViewById(R.id.txtUsername);
        txtFirstName = (EditText) findViewById(R.id.txtFirstName);
        txtLastName = (EditText) findViewById(R.id.txtLastName);
        txtAddress = (EditText) findViewById(R.id.txtAddress);
        txtPostalCode = (EditText) findViewById(R.id.txtPostalCode);

        btnAddCustomer = (Button) findViewById(R.id.btnAddCustomer);
        btnShowCustomer = (Button) findViewById(R.id.btnShowCustomer);
        btnEditCustomer = (Button) findViewById(R.id.btnEditCustomer);


        //Order Table
        txtOrderId = (EditText) findViewById(R.id.txtOrderId);
        txtOItemId = (EditText) findViewById(R.id.txtOItemId);
        txtOAmount = (EditText) findViewById(R.id.txtOAmount);
        txtODeliveryDate = (EditText) findViewById(R.id.txtODeliveryDate);
        txtOStatus = (EditText) findViewById(R.id.txtOStatus);

        btnAddOrder = (Button) findViewById(R.id.btnAddOrder);
        btnShowOrder = (Button) findViewById(R.id.btnShowOrder);
        btnEditOrder = (Button) findViewById(R.id.btnEditOrder);
        btnViewItemCus = (Button) findViewById(R.id.btnViewItemCus);


        // instantiate the StudentManager
        // initialize the tables
        try {
            customerManager = new tblmgrCustomer(this);
            //create the table
            customerManager.dbInitialize(TABLE_NAME, tableCreatorString);
        } catch (Exception exception) {
            Toast.makeText(PlaceOrder.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
            Log.i("Error: ", exception.getMessage());
        }

        try {
            ordersManager = new tblmgrOrders(this);
            //create the table
            ordersManager.dbInitialize(TABLE_NAME_ORDER, tableCreatorStringOrder);
        } catch (Exception exception) {
            Toast.makeText(PlaceOrder.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
            Log.i("Error: ", exception.getMessage());
        }

        try {
            itemManager = new tblmgrItems(this);
            //create the table
            itemManager.dbInitialize(TABLE_NAME_ITEM, tableCreatorStringItem);
        } catch (Exception exception) {
            Toast.makeText(PlaceOrder.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
            Log.i("Error: ", exception.getMessage());
        }

    } //end of onCreate

    //Event handling
    public void addCustomer(View view) {
        //read values for text fields
        int customerId = Integer.parseInt(idCus);
        String username = usernameCus;
        String password = passwordCus;
        String firstName = txtFirstName.getText().toString();
        String lastName = txtLastName.getText().toString();
        String address = txtAddress.getText().toString();
        String postalCode = txtPostalCode.getText().toString();
        //initialize ContentValues object with the new customer
        ContentValues customerContentValues = new ContentValues();
        customerContentValues.put("customerId", customerId);
        customerContentValues.put("username", username);
        customerContentValues.put("password", password);
        customerContentValues.put("firstName", firstName);
        customerContentValues.put("lastName", lastName);
        customerContentValues.put("address", address);
        customerContentValues.put("postalCode", postalCode);
        //
        try {
            customerManager.addRow(customerContentValues);
        } catch (Exception exception) {
            //
            Toast.makeText(PlaceOrder.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
            Log.i("Error: ", exception.getMessage());
        }
    }

    public void showCustomer(View view) {
        try {
            tblCustomer customer = customerManager.getCustomerById(Integer.parseInt(idCus), "customerId");
            txtUsername.setText(customer.getUsername());
            txtFirstName.setText(customer.getFirstName());
            txtLastName.setText(customer.getLastName());
            txtAddress.setText(customer.getAddress());
            txtPostalCode.setText(customer.getPostalCode());
        } catch (Exception exception) {
            Toast.makeText(PlaceOrder.this,
                    exception.getMessage(), Toast.LENGTH_SHORT).show();
            Log.i("Error: ", exception.getMessage());

        }
    }

    public void editCustomer(View view) {
        int customerId = Integer.parseInt(idCus);

        String username = usernameCus;
        String password = passwordCus;
        String firstName = txtFirstName.getText().toString();
        String lastName = txtLastName.getText().toString();
        String address = txtAddress.getText().toString();
        String postalCode = txtPostalCode.getText().toString();

        try {
            ContentValues customerContentValues = new ContentValues();
            customerContentValues.put("customerId", customerId);
            customerContentValues.put("username", username);
            customerContentValues.put("password", password);
            customerContentValues.put("firstName", firstName);
            customerContentValues.put("lastName", lastName);
            customerContentValues.put("address", address);
            customerContentValues.put("postalCode", postalCode);
            //edit the row
            boolean b = customerManager.editRow(customerId, "customerId", customerContentValues);
        } catch (Exception exception) {
            Toast.makeText(PlaceOrder.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
            Log.i("Error: ", exception.getMessage());
        }
    }

    //Event handling
    public void addOrder(View view) {
        //read values for text fields
        int orderId = Integer.parseInt(txtOrderId.getText().toString());
        int itemId = Integer.parseInt(txtOItemId.getText().toString());
        int customerId = Integer.parseInt(idCus);
        String amount = txtOAmount.getText().toString();
        String deliveryDate = txtODeliveryDate.getText().toString();
        String status = txtOStatus.getText().toString();

        //initialize ContentValues object with the new customer
        ContentValues orderContentValues = new ContentValues();
        orderContentValues.put("orderId", orderId);
        orderContentValues.put("itemId", itemId);
        orderContentValues.put("customerId", customerId);
        orderContentValues.put("amount", amount);
        orderContentValues.put("deliveryDate", deliveryDate);
        orderContentValues.put("status", status);
        //
        try {
            ordersManager.addRow(orderContentValues);
        } catch (Exception exception) {
            //
            Toast.makeText(PlaceOrder.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
            Log.i("Error: ", exception.getMessage());
        }
    }

    public void showOrder(View view) {
        try {
            tblOrders order = ordersManager.getOrdersById(Integer.parseInt(txtOrderId.getText().toString()), "orderId");
            txtOItemId.setText(String.valueOf(order.getItemId()));
            txtOAmount.setText(order.getAmount());
            txtODeliveryDate.setText(order.getDeliveryDate());
            txtOStatus.setText(order.getStatus());
        } catch (Exception exception) {
            Toast.makeText(PlaceOrder.this,
                    exception.getMessage(), Toast.LENGTH_SHORT).show();
            Log.i("Error: ", exception.getMessage());

        }
    }

    public void editOrder(View view) {
        int orderId = Integer.parseInt(txtOrderId.getText().toString());
        int itemId = Integer.parseInt(txtOItemId.getText().toString());
        int customerId = Integer.parseInt(idCus);
        String amount = txtOAmount.getText().toString();
        String deliveryDate = txtODeliveryDate.getText().toString();
        String status = txtOStatus.getText().toString();

        try {
            ContentValues orderContentValues = new ContentValues();
            orderContentValues.put("orderId", orderId);
            orderContentValues.put("itemId", itemId);
            orderContentValues.put("customerId", customerId);
            orderContentValues.put("amount", amount);
            orderContentValues.put("deliveryDate", deliveryDate);
            orderContentValues.put("status", status);
            //edit the row
            boolean b = ordersManager.editRow(orderId, "orderId", orderContentValues);
        } catch (Exception exception) {
            Toast.makeText(PlaceOrder.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
            Log.i("Error: ", exception.getMessage());
        }
    }

    public void CancelOrder(View view) {
        int orderId = Integer.parseInt(txtOrderId.getText().toString());
        try {
            //edit the row
            boolean b = ordersManager.deleteRow(orderId, "orderId");
        } catch (Exception exception) {
            Toast.makeText(PlaceOrder.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
            Log.i("Error: ", exception.getMessage());
        }
    }

    public void showItem(View view) {
        try {
            tblItems item = itemManager.getItemById(Integer.parseInt(txtOItemId.getText().toString()), "itemId");
            String itemName = item.getItemName();
            String itemPrice = item.getPrice();
            String itemCategory = item.getCategory();

            SharedPreferences itemPreference = getSharedPreferences("ItemDetail", 0);
            SharedPreferences.Editor itemEditor = itemPreference.edit();
            itemEditor.putString("ItemName", itemName);
            itemEditor.putString("ItemPrice", itemPrice);
            itemEditor.putString("ItemCategory", itemCategory);
            itemEditor.commit();
            Intent intent = new Intent(this, ItemDetails.class);
            startActivity(intent);

        } catch (Exception exception) {
            Toast.makeText(PlaceOrder.this,
                    exception.getMessage(), Toast.LENGTH_SHORT).show();
            Log.i("Error: ", exception.getMessage());

        }
    }
}
