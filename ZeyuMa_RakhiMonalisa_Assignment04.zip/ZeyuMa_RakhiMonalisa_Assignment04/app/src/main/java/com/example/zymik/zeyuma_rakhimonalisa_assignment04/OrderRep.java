package com.example.zymik.zeyuma_rakhimonalisa_assignment04;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class OrderRep extends AppCompatActivity {

    private tblmgrOrderRep orderRepManager;
    private final static String TABLE_NAME = "OrderRep";
    //sql string to create the table
    private static final String tableCreatorString =
            "CREATE TABLE " + TABLE_NAME + " (orderRepId integer primary key, username text, password text, firstName text, lastName text);";

    private tblmgrOrders ordersManager;
    private final static String TABLE_NAME_ORDER = "Orders";
    //sql string to create the table
    private static final String tableCreatorStringOrder =
            "CREATE TABLE " + TABLE_NAME_ORDER + " (orderId integer primary key, itemId integer, customerId integer, amount text, deliveryDate text, status text);";

    //EditText for OrderRep
    private EditText txtUsernameRep, txtFirstNameRep, txtLastNameRep;
    private Button btnAddOrderRep;

    //For Orders
    private EditText txtOrderIdRep;
    private TextView txtvItemIdShow, txtvCustomerIdShow, txtvAmountShow, txtvDeliveryDateShow, txtvStatusShow;
    private Button btnViewOrderRep, btnEditOrderRep, btnEditItemRep;
    private String idRep, usernameRep, passwordRep;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_rep);
        SharedPreferences orderRepPreference = getSharedPreferences("OrderRepInfo", MODE_PRIVATE);
        idRep = orderRepPreference.getString("OrderRepId", "");
        usernameRep = orderRepPreference.getString("OrderRepUsername", "");
        passwordRep = orderRepPreference.getString("OrderRepPassword", "");

        //Order Rep Table
        txtUsernameRep = (EditText) findViewById(R.id.txtUsernameRep);
        txtFirstNameRep = (EditText) findViewById(R.id.txtFirstNameRep);
        txtLastNameRep = (EditText) findViewById(R.id.txtLastNameRep);

        btnAddOrderRep = (Button) findViewById(R.id.btnAddRep);


        //Orders Table
        txtOrderIdRep = (EditText) findViewById(R.id.txtOrderIdRep);
        txtvItemIdShow = (TextView) findViewById(R.id.txtvItemIdShow);
        txtvCustomerIdShow = (TextView) findViewById(R.id.txtvCustomerIdShow);
        txtvAmountShow = (TextView) findViewById(R.id.txtvAmountShow);
        txtvDeliveryDateShow = (TextView) findViewById(R.id.txtvDeliveryDateShow);
        txtvStatusShow = (TextView) findViewById(R.id.txtvStatusShow);

        // instantiate the StudentManager
        // initialize the tables
        try {
            orderRepManager = new tblmgrOrderRep(this);
            //create the table
            orderRepManager.dbInitialize(TABLE_NAME, tableCreatorString);
        } catch (Exception exception) {
            Toast.makeText(OrderRep.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
            Log.i("Error: ", exception.getMessage());
        }

        try {
            ordersManager = new tblmgrOrders(this);
            //create the table
            ordersManager.dbInitialize(TABLE_NAME_ORDER, tableCreatorStringOrder);
        } catch (Exception exception) {
            Toast.makeText(OrderRep.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
            Log.i("Error: ", exception.getMessage());
        }

    }

    //Event handling
    public void addOrderRep(View view) {
        //read values for text fields
        int orderRepId = Integer.parseInt(idRep);
        String username = usernameRep;
        String password = passwordRep;
        String firstName = txtFirstNameRep.getText().toString();
        String lastName = txtLastNameRep.getText().toString();

        //initialize ContentValues object with the new customer
        ContentValues orderRepContentValues = new ContentValues();
        orderRepContentValues.put("orderRepId", orderRepId);
        orderRepContentValues.put("username", username);
        orderRepContentValues.put("password", password);
        orderRepContentValues.put("firstName", firstName);
        orderRepContentValues.put("lastName", lastName);
        //
        try {
            orderRepManager.addRow(orderRepContentValues);
        } catch (Exception exception) {
            //
            Toast.makeText(OrderRep.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
            Log.i("Error: ", exception.getMessage());
        }
    }

    public void showRep(View view) {
        try {
            tblOrderRep orderRep = orderRepManager.getOrderRepById(Integer.parseInt(idRep), "orderRepId");
            txtUsernameRep.setText(orderRep.getUsername());
            txtFirstNameRep.setText(orderRep.getFirstName());
            txtLastNameRep.setText(orderRep.getLastName());
        } catch (Exception exception) {
            Toast.makeText(OrderRep.this,
                    exception.getMessage(), Toast.LENGTH_SHORT).show();
            Log.i("Error: ", exception.getMessage());
        }
    }

    public void showOrder(View view) {
        try {
            tblOrders order = ordersManager.getOrdersById(Integer.parseInt(txtOrderIdRep.getText().toString()), "orderId");
            txtvItemIdShow.setText(String.valueOf(order.getItemId()));
            txtvCustomerIdShow.setText(String.valueOf(order.getCustomerId()));
            txtvAmountShow.setText(order.getAmount());
            txtvDeliveryDateShow.setText(order.getDeliveryDate());
            txtvStatusShow.setText(order.getStatus());
        } catch (Exception exception) {
            Toast.makeText(OrderRep.this,
                    exception.getMessage(), Toast.LENGTH_SHORT).show();
            Log.i("Error: ", exception.getMessage());
        }

        /*try {
            tblOrders order = ordersManager.getOrdersById(Integer.parseInt(txtOrderIdRep.getText().toString()), "orderId");
            txtOItemId.setText(String.valueOf(order.getItemId()));
            txtOAmount.setText(order.getAmount());
            txtODeliveryDate.setText(order.getDeliveryDate());
            txtOStatus.setText(order.getStatus());
        } catch (Exception exception) {
            Toast.makeText(PlaceOrder.this,
                    exception.getMessage(), Toast.LENGTH_SHORT).show();
            Log.i("Error: ", exception.getMessage());

        }*/
    }

    public void editOrder(View view) {
        int orderId = Integer.parseInt(txtOrderIdRep.getText().toString());

        txtvStatusShow.setText("Delivered");
        String status = txtvStatusShow.getText().toString();

        try {
            ContentValues orderContentValues = new ContentValues();
            orderContentValues.put("orderId", orderId);
            orderContentValues.put("status", status);
            //edit the row
            boolean b = ordersManager.editRow(orderId, "orderId", orderContentValues);
        } catch (Exception exception) {
            Toast.makeText(OrderRep.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
            Log.i("Error: ", exception.getMessage());
        }
    }

    public void editItemDetails(View view){
        Intent intentOrder = new Intent(this, ItemList.class);
        startActivity(intentOrder);
    }
}
