package com.example.zymik.zeyuma_rakhimonalisa_assignment04;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private EditText idCus;
    private EditText usernameCus;
    private EditText passwordCus;
    private EditText idRep;
    private EditText usernameRep;
    private EditText passwordRep;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        idCus = (EditText)findViewById(R.id.txtId);
        usernameCus = (EditText)findViewById(R.id.txtUserName);
        passwordCus = (EditText)findViewById(R.id.txtPassword);
        idRep = (EditText)findViewById(R.id.txtEId);
        usernameRep = (EditText)findViewById(R.id.txtEUsername);
        passwordRep = (EditText)findViewById(R.id.txtEPassword);


    }

    public void customerLogin(View view){
        SharedPreferences customerPreference = getSharedPreferences("CustomerInfo", 0);
        SharedPreferences.Editor customerEditor = customerPreference.edit();
        customerEditor.putString("CustomerId", idCus.getText().toString());
        customerEditor.putString("CustomerUsername", usernameCus.getText().toString());
        customerEditor.putString("CustomerPassword", passwordCus.getText().toString());

        customerEditor.commit();

        Intent intentOrder = new Intent(this, PlaceOrder.class);
        startActivity(intentOrder);
    }

    public void orderRepLogin(View view){
        SharedPreferences orderRepPreference = getSharedPreferences("OrderRepInfo", 0);
        SharedPreferences.Editor orderRepEditor = orderRepPreference.edit();
        orderRepEditor.putString("OrderRepId", idRep.getText().toString());
        orderRepEditor.putString("OrderRepUsername", usernameRep.getText().toString());
        orderRepEditor.putString("OrderRepPassword", passwordRep.getText().toString());

        orderRepEditor.commit();

        Intent intentOrder = new Intent(this, OrderRep.class);
        startActivity(intentOrder);
    }


}
