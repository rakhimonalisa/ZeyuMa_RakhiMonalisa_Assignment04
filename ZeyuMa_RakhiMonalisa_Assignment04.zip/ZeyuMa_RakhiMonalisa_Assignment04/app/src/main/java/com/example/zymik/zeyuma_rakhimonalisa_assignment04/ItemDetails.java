package com.example.zymik.zeyuma_rakhimonalisa_assignment04;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class ItemDetails extends AppCompatActivity {

    TextView txtvDisplayName, txtvDisplayPrice, txtvDisplayCategory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_details);

        //retrieving from shared preferences
        SharedPreferences itemPref = getSharedPreferences("ItemDetail", MODE_PRIVATE);
        String itemName = itemPref.getString("ItemName","");
        String itemPrice = itemPref.getString("ItemPrice","");
        String itemCategory = itemPref.getString("ItemCategory","");

        txtvDisplayName = (TextView) findViewById(R.id.txtvDisplayName);
        txtvDisplayName.setText(itemName);

        txtvDisplayPrice = (TextView) findViewById(R.id.txtvDisplayPrice);
        txtvDisplayPrice.setText(itemPrice);

        txtvDisplayCategory = (TextView) findViewById(R.id.txtvDisplayCategory);
        txtvDisplayCategory.setText(itemCategory);
    }
}
